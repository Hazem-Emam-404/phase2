#ifndef MuteAction_h
#define MuteAction_h
#include"Actions/Action.h"
class MuteAction :public Action
{
public:
	MuteAction(ApplicationManager*);
	virtual void ReadActionParameters();
	virtual void Execute();


};
#endif
