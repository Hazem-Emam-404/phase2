#pragma once
#include"Actions/Action.h"
#include"ApplicationManager.h"
class PlayRecordingAction : public Action
{
public:
	PlayRecordingAction(ApplicationManager* pApp);
	void ReadActionParameters();
	void Execute();
};

