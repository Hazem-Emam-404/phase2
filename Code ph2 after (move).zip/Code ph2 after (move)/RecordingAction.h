#pragma once
#include "Actions/Action.h"
#include"ApplicationManager.h"
class RecordingAction : public Action
{
public:
	RecordingAction(ApplicationManager* pApp);
	void ReadActionParameters();
	void Execute();
};

