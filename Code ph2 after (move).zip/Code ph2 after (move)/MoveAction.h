#ifndef MOVE_ACTION_H
#define MOVE_ACTION_H
#include "Actions/Action.h"

// move Action Class 
class MoveAction :public Action
{
private:
	Point P;
	bool isvalid(Point P) const;

public:
	MoveAction(ApplicationManager* pApp);

	//Reads parameters (the point wich the figure move to)
	virtual void ReadActionParameters();

	// Excute move Action
	virtual void Execute();


};

#endif





