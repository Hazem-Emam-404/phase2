#include "FillColorAction.h"
#include "ApplicationManager.h"

#include "GUI/Input.h"
#include "GUI/Output.h"

FillColorAction::FillColorAction(ApplicationManager* pApp):Action(pApp)
{
}

void FillColorAction::ReadActionParameters()
{
	//Get a Pointer to the Input / Output Interfaces
	Output* pOut = pManager->GetOutput();
	Input* pIn = pManager->GetInput();

	if (pManager->ifselected() == 0) // Check if there is selected figure
	{         
		pOut->PrintMessage("Fill Color icon ... Please select figure first ");
	}
	
	else
	{
		pOut->PrintMessage("Fill Color icon ... Please choose the color ");        // Get the color to change
		do {
			Act = pManager->GetUserAction();
			if (!(Act == rED || Act == gREEN || Act == yELLOW || Act == oRANGEE || Act == bLUE || Act == bLACK))
				pOut->PrintMessage("Invalid....Please choose color from color icons ");
		} while (!(Act == rED || Act == gREEN || Act == yELLOW || Act == oRANGEE || Act == bLUE || Act == bLACK));
		pOut->ClearStatusBar();
	}

}

void FillColorAction::Execute()
{
	ReadActionParameters();
	if (pManager->ifselected()) {
	switch (Act) {
	case rED:
		UI.FillColor = RED;
		break;
	case gREEN:
		UI.FillColor = GREEN;
		break;
	case yELLOW:
		UI.FillColor = YELLOW;
		break;
	case oRANGEE:
		UI.FillColor = ORANGE;
		break;
	case bLUE:
		UI.FillColor = BLUE;
		break;
	case bLACK:
		UI.FillColor = BLACK;
		break;
	}
	
		pManager->ChngSelectedCLR('F'); //change the selected figure's fill color
		fill = true;
	}
	pManager->PrintSelectedInfo();
}
