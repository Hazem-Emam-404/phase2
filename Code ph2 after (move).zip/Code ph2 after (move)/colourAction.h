#ifndef colourAction_h
#define colourAction_h
#include"Actions/Action.h"
class colourAction   :public Action
{

protected:
	Point p1;
	string colour;
public: 
	colourAction(ApplicationManager*);
	virtual void ReadActionParameters();
	virtual void Execute();
};
#endif