#include "DrwColorAction.h"
#include "ApplicationManager.h"

#include "GUI/Input.h"
#include "GUI/Output.h"
DrwColorAction::DrwColorAction(ApplicationManager* pApp) :Action(pApp)
{
}





void DrwColorAction::ReadActionParameters()
{
	//Get a Pointer to the Input / Output Interfaces
	Output* pOut = pManager->GetOutput();
	Input* pIn = pManager->GetInput();

	if (pManager->ifselected() == 0) {         // Check if there is selected figure
		pOut->PrintMessage("Draw Color icon ... Please select figure first ");
	}
	else
	{
		pOut->PrintMessage("Draw Color icon ... Please choose the color ");        // Get the color to change
		do {
			Act = pManager->GetUserAction();
			if (!(Act == rED || Act == gREEN || Act == yELLOW || Act == oRANGEE || Act == bLUE || Act == bLACK))
				pOut->PrintMessage("Invalid....Please choose color from color icons ");
		} while (!(Act == rED || Act == gREEN || Act == yELLOW || Act == oRANGEE || Act == bLUE || Act == bLACK));
		pOut->ClearStatusBar();
	}
}
void DrwColorAction::Execute()
{

		ReadActionParameters();
		if (pManager->ifselected()) {
		switch (Act) {
		case rED:
			UI.DrawColor = RED;
			break;
		case gREEN:
			UI.DrawColor = GREEN;
			break;
		case yELLOW:
			UI.DrawColor = YELLOW;
			break;
		case oRANGEE:
			UI.DrawColor = ORANGE;
			break;
		case bLUE:
			UI.DrawColor = BLUE;
			break;
		case bLACK:
			UI.DrawColor = BLACK;
			break;
		}
	
			pManager->ChngSelectedCLR('D'); // change the selected figure's draw color
		}
		pManager->PrintSelectedInfo();


}