#include "RecordingAction.h"

RecordingAction::RecordingAction(ApplicationManager* pApp):Action(pApp)
{
}

void RecordingAction::ReadActionParameters()
{
	Output* output = pManager->GetOutput();
	output->PrintMessage("you just statreted recording , Note that this action will not record the operations in play mode ");
	string s;   //to print message with integer numbers
	int performed=0;  // counter for performed actions
	for (int i = 0; i < 20; i++)
	{
		Input* input = pManager->GetInput();
		ActionType a = input->GetUserAction();
		ActionType* p = new ActionType(a);
		Point point{};

		while (a == RECORD)      //i can't do a record to the record(special case)
		{
			output->PrintMessage("that is invalid point , click a valid one");
			a=input->GetUserAction();
		}
		if (a == EXIT)          //can't be recorded (special case)
		{
			output->PrintMessage("you will close the program");
			pManager->ExecuteAction(a);
			break;
		}
		if (a == PLAYREC)  //we must play record after the record finish
		{
			output->PrintMessage("in valid point , click a valid one");
		}
		else if (a == STOPRECORD)    //finish record  (special case)
		{
			output->PrintMessage("The record has been finished and your number of operations are: "+to_string(performed));
			break;
		}
		////////// actions that i don't wnat to record it//////////////
		else if ( (a == SAVE) || (a == UPLOAD)  || (a == PLAY) || (a == draw)||(a==DRAWING_AREA)||(a==STATUS)||(a== PLAYING_AREA)||(a==EMPTY)||(a== stopplay)||(a== shapecolour)||(a==shape)||(a==colour))
		{
			output->PrintMessage("this action has not recorded ,click any point to complete this operation");
			input->GetPointClicked(point.x, point.y);
			pManager->ExecuteAction(a);
		}
		else if (a == Delete)    ///// to delete all actions and figures that has been done and reset the record(special case)
		{
			i = -1,performed=0;  //refresh the loop by i=-1 and performed operations to zero
			pManager->ExecuteAction(a);
			output->PrintMessage("your Records have been Zero and we deleted all history in the App, click any action to start your new record");
		}
		else 
		{
			performed++;  //counter increases by each operation has been recorded
	        s = "your actions that have been recorded are " + to_string(performed );
			output->PrintMessage(s);
			Sleep(1000);           //only to see the above message
			pManager->ExecuteAction(a);
			pManager->UpdateInterface();  // to see what you do
			pManager->Addaction(p);  // add to the actions array
		}
	}
}

void RecordingAction::Execute()
{
	ReadActionParameters();
}
