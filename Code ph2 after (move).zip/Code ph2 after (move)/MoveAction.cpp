#include "MoveAction.h"
#include "ApplicationManager.h"
#include "GUI/Input.h"
#include "GUI/Output.h"


MoveAction::MoveAction(ApplicationManager* pApp): Action(pApp)
{
}

void MoveAction::ReadActionParameters()
{
	//Get a Pointer to the Input / Output Interfaces
	Output* pOut = pManager->GetOutput();
	Input* pIn = pManager->GetInput();

	if (pManager->ifselected() == 0) // Check if there is selected figure
	{
		pOut->PrintMessage("Move icon ... Please select figure first ");
	}
	else {
		pOut->PrintMessage("Move icon ... click on the point you want to move"); // Get the Point to move
		do {
			pIn->GetPointClicked(P.x, P.y);
			if(!isvalid(P)) pOut->PrintMessage("Invalid Point ... click another point");
		} while (!isvalid(P));
		pOut->ClearStatusBar();
	}

}

void MoveAction::Execute()
{
	ReadActionParameters();
	if(pManager->ifselected()) {            
		pManager->MoveSelectedFig(P); //move the selected figure
		
		pManager->PrintSelectedInfo();  // print info about the selected figure
	}
}

bool MoveAction::isvalid(Point P) const // chaek the validation of the point
{
	if (P.y<(UI.ToolBarHeight+3) || P.y>(UI.height - UI.StatusBarHeight)) return false;
	return true;
}