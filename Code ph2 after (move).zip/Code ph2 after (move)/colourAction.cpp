#include "colourAction.h"
#include "ApplicationManager.h"
#include "GUI/Input.h"
#include "GUI/Output.h"
#include <random>
#include<cmath>
#include<Windows.h>
#include<mmsystem.h>
#include<cstring>
colourAction::colourAction(ApplicationManager* p):Action(p)
{
}

void colourAction::ReadActionParameters()
{
	Output* pOut = pManager->GetOutput();
	Input* pIn = pManager->GetInput();
	 
}

void colourAction::Execute()
{
    Input* pIn = pManager->GetInput();
    Output* pOut = pManager->GetOutput();
  
    if (pManager->GetFigCount() == 0)
    {
        pOut->PrintMessage("THERE ARE NO SHAPES TO PICK");
    }
    else  if (pManager->GetFigCount() == 1)
    {
        pOut->PrintMessage("DRAW MORE SHAPES");
    }
    else if (!(pManager->isanyfill()))
    {
        pOut->PrintMessage("NO FILL COLOUR SHAPES");
    }
   
    else if ((pManager->isanyfill()) && (pManager->GetFigCount() > 1))
    {
        int random_number=0;
        do
        {  
            random_device rd;
            mt19937 gen(rd());
            uniform_int_distribution<> distribution(0,(pManager->GetFigCount()-1));
            random_number = distribution(gen);
        } while ((pManager->Getshape(random_number)->colourshape()=="WHITE")||(pManager->Getshape(random_number))==0);
        colour = (pManager->Getshape(random_number))->colourshape();
        { if (colour == "RED")
        {
            pOut->PrintMessage("PICK ALL RED SHAPES....ARE YOU READY CLICK ANY WHERE TO START");
            pIn->GetPointClicked(p1.x, p1.y);
        }
        else if (colour == "GREEN")
        {
            pOut->PrintMessage("PICK ALL GREEN SHAPES....ARE YOU READY CLICK ANY WHERE TO START");
            pIn->GetPointClicked(p1.x, p1.y);
        }
        else if (colour == "YELLOW")
        {
            pOut->PrintMessage("PICK ALL YELLOW SHAPES....ARE YOU READY CLICK ANY WHERE TO START");
            pIn->GetPointClicked(p1.x, p1.y);
        }
        else if (colour == "ORANGE")
        {
            pOut->PrintMessage("PICK ALL ORANGE SHAPES....ARE YOU READY CLICK ANY WHERE TO START");
            pIn->GetPointClicked(p1.x, p1.y);
        }
        else if (colour == "BLUE....ARE YOU READY CLICK ANY WHERE TO START")
        {
            pOut->PrintMessage("PICK ALL BLUE SHAPES....ARE YOU READY CLICK ANY WHERE TO START");
            pIn->GetPointClicked(p1.x, p1.y);
        }
        else if (colour == "BLACK")
        {
            pOut->PrintMessage("PICK ALL BLACK SHAPES....ARE YOU READY CLICK ANY WHERE TO START");
            pIn->GetPointClicked(p1.x, p1.y);
        }

        }
    }  
    if ((pManager->isanyfill())&&(pManager->GetFigCount()>1))
    {
        int k = (pManager->numsamecolour(colour));
        ActionType check;
        do
        {
            pIn->GetPointClicked(p1.x, p1.y);
            if (pManager->GetFigure(p1) != 0)
            {
                if ((pManager->GetFigure(p1))->colourshape() == colour)
                {    
                    pManager->deleteshape(p1);
                    pOut->PrintMessage(" GOOD JOB.....  ");
                    if (pManager->getcheckvoice())
                    {
                        PlaySound(TEXT("good jj.wav"), NULL, SND_FILENAME | SND_SYNC);
                    }
                    k--;
                    if (k == 0)
                    {
                        pOut->PrintMessage("YOU ARE A CLEVER KID...YOU WIN");
                        if (pManager->getcheckvoice())
                        {
                            PlaySound(TEXT("allah.wav"), NULL, SND_FILENAME | SND_SYNC);
                        }
                        break;
                    }
                }
                else
                {
                    pOut->PrintMessage(" FOCUS AND TRY AGAIN .... ");
                    if (pManager->getcheckvoice())
                    {
                      PlaySound(TEXT("eh da.wav"), NULL, SND_FILENAME | SND_SYNC);
                    }
                }
                pOut->PrintMessage("IF YOU WANT TO STOP PLAY CLICK ON STOP PLAY ICON");
                check = pManager->GetUserAction();
                if (check == stopplay)
                {
                    pOut->ClearStatusBar();
                    break;
                }
            }
        } while (1);
    }
}

