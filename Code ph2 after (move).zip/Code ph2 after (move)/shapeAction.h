#ifndef shapeAction_h
#define shapeAction_h
#include"Actions/Action.h"
class shapeAction :public Action
{
protected:
	Point p1; 
	char keyShape;
public:
	shapeAction(ApplicationManager*);
	virtual void ReadActionParameters();
	virtual void Execute();


};
#endif

