#pragma once
#include "Actions/Action.h"

//Add Square Action class
class AddHexaAction : public Action
{
private:
	Point Center; // Hexagon Center
	GfxInfo HexaGfxInfo;

	//Check validation of the center point
	bool isvalid(Point center);

public:
	AddHexaAction(ApplicationManager* pApp);

	//Reads Hexagon parameters
	virtual void ReadActionParameters();

	//Add Hexagon to the ApplicationManager
	virtual void Execute();

};

