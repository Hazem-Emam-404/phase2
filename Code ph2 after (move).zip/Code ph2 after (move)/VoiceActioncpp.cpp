#include "VoiceAction.h"
#include"ApplicationManager.h"

VoiceAction::VoiceAction(ApplicationManager* p) :Action(p)
{

}
void VoiceAction::ReadActionParameters()
{
	Output* pOut = pManager->GetOutput();
	Input* pIn = pManager->GetInput();
}

void VoiceAction::Execute()
{
	Output* pOut = pManager->GetOutput();
	pOut->PrintMessage("this will make voice of some action ");
	Sleep(1000);
	pManager->setcheckvoice(1);
	pOut->ClearStatusBar();
}