#ifndef DRW_ACT
#define DRW_ACT
#include "Actions/Action.h"
class DrwColorAction :  public Action
{
	ActionType Act;
public:
	DrwColorAction(ApplicationManager* pApp);

	//Reads Square parameters
	virtual void ReadActionParameters();

	//Add Sqaure to the ApplicationManager
	virtual void Execute();


};
#endif DRW_ACT
