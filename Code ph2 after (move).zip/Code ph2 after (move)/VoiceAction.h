#ifndef VoiceAction_h
#define VoiceAction_h
#include"Actions/Action.h"
class VoiceAction:public Action
{
public:
	VoiceAction(ApplicationManager* );
	virtual void ReadActionParameters();
	virtual void Execute();


};
#endif