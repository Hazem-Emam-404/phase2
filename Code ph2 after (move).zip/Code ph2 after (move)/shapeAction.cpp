#include "ApplicationManager.h"
#include "GUI/Input.h"
#include "GUI/Output.h"
#include"shapeAction.h"
#include <random>
#include<cmath>
#include<Windows.h>
#include<mmsystem.h>

shapeAction::shapeAction(ApplicationManager* p):Action(p)
{
	
}

void shapeAction::ReadActionParameters()
{
	//Get a Pointer to the Input / Output Interfaces
	Output* pOut = pManager->GetOutput();
	Input* pIn = pManager->GetInput();
   
	//Get the point which select the figure
	pIn->GetPointClicked(p1.x, p1.y);
	pOut->ClearStatusBar();
}

void shapeAction::Execute()
{
    Input* pIn = pManager->GetInput();
    Output* pOut = pManager->GetOutput();
    int random_number=0;
    if (pManager->GetFigCount() == 0) {
        pOut->PrintMessage("THERE ARE NO SHAPES TO PICK");
    }
    else  if (pManager->GetFigCount() == 1) 
    {
        pOut->PrintMessage("DRAW MORE SHAPES");
    }
        else if(pManager->GetFigCount()>1)
        {
        
             do
             {
                random_device rd;
                mt19937 gen(rd());
                uniform_int_distribution<> distribution(0, (pManager->GetFigCount()-1));
                random_number = distribution(gen);
             } while (pManager->Getshape(random_number) == 0);
                CFigure* shape = pManager->Getshape(random_number);
                if (shape != NULL)
                {
                     keyShape = shape->keyshape();
                    switch (keyShape)
                    {
                        case '!':
                        { pOut->PrintMessage("Pick all Circle shapes......are you ready click anywhere to start");
                        pIn->GetPointClicked(p1.x, p1.y);
                        break;
                        }
                        case '@':
                        { pOut->PrintMessage("Pick all Hexagonal shapes......are you ready click anywhere to start");
                        pIn->GetPointClicked(p1.x, p1.y);
                        break;
                        }

                        case '#':
                        { pOut->PrintMessage("Pick all Square shapes......are you ready click anywhere to start");
                        pIn->GetPointClicked(p1.x, p1.y);
                        break;
                        }

                        case '*':
                        { pOut->PrintMessage("Pick all Triangle shapes......are you ready click anywhere to start");
                        pIn->GetPointClicked(p1.x, p1.y);
                        break;
                        }
                        case '$':
                        { pOut->PrintMessage("Pick all Rectangle shapes......are you ready click anywhere to start");
                        pIn->GetPointClicked(p1.x, p1.y);
                        break;
                        }
                       
                            
                    }
                }
               pOut->PrintMessage("lets go");
        }
    
    if ( pManager->GetFigCount() > 1)
    {
   
        int k = (pManager->numgivenkeyshape(keyShape));
        ActionType check;
        do
        {
            pIn->GetPointClicked(p1.x, p1.y);
            if (pManager->GetFigure(p1) != 0)
            {
                if ((pManager->GetFigure(p1))->keyshape() == keyShape)
                {    
                    pManager->deleteshape(p1);
                    pOut->PrintMessage(" GOOD JOB.....  ");
                    Sleep(500);
                    if (pManager->getcheckvoice())
                    {
                        PlaySound(TEXT("good jj.wav"), NULL, SND_FILENAME | SND_SYNC);
                    }
                    k--;
                    if (k == 0)
                    {
                        pOut->PrintMessage("YOU ARE A CLEVER KID...YOU WIN");
                        if (pManager->getcheckvoice())
                        {
                            PlaySound(TEXT("allah"), NULL, SND_FILENAME | SND_SYNC);
                        }
                        break;
                    }
                }
                else
                {    
                    pOut->PrintMessage(" FOCUS AND TRY AGAIN .... ");
                    Sleep(500);
                    if (pManager->getcheckvoice() == 1)
                    {
                        PlaySound(TEXT("eh da.wav"), NULL, SND_FILENAME | SND_SYNC);
                    }
                }  
                pOut->PrintMessage("IF YOU WANT TO STOP PLAY CLICK ON STOP PLAY ICON");
                check = pManager->GetUserAction();
                if (check==stopplay)
                {
                    pOut->ClearStatusBar();
                    break;
                }
            }
        } while (1);
    }
     
}

  

   



